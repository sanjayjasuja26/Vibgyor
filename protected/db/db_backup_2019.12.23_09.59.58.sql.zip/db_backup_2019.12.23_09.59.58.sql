SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
-- -------------------------------------------
SET AUTOCOMMIT=0;
START TRANSACTION;
SET SQL_QUOTE_SHOW_CREATE = 1;
-- -------------------------------------------

-- -------------------------------------------

-- START BACKUP

-- -------------------------------------------

-- -------------------------------------------

-- TABLE `ha_logins`

-- -------------------------------------------
DROP TABLE IF EXISTS `ha_logins`;
CREATE TABLE IF NOT EXISTS `ha_logins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `loginProvider` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `loginProviderIdentifier` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `loginProvider_2` (`loginProvider`,`loginProviderIdentifier`),
  KEY `loginProvider` (`loginProvider`),
  KEY `loginProviderIdentifier` (`loginProviderIdentifier`),
  KEY `userId` (`userId`),
  KEY `id` (`id`),
  KEY `user_id` (`id`),
  KEY `fk_ha_logins_created_by` (`user_id`),
  CONSTRAINT `fk_ha_logins_user` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_blog_category`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_blog_category`;
CREATE TABLE IF NOT EXISTS `tbl_blog_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `state_id` (`state_id`),
  KEY `FK_blog_category_created_by_id` (`created_by_id`),
  CONSTRAINT `FK_blog_category_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_blog_post`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_blog_post`;
CREATE TABLE IF NOT EXISTS `tbl_blog_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_file` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `view_count` int(11) NOT NULL DEFAULT '0',
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `keywords` (`keywords`),
  KEY `state_id` (`state_id`),
  KEY `created_on` (`created_on`),
  KEY `FK_blog_created_by_id` (`created_by_id`),
  CONSTRAINT `FK_blog_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_category`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_category_created_by` (`created_by_id`),
  CONSTRAINT `fk_category_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_check`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_check`;
CREATE TABLE IF NOT EXISTS `tbl_check` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `street_name` text NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `qweqweqwk` int(11) NOT NULL,
  `eqweqwa` int(11) NOT NULL,
  `eqweouiy` int(11) NOT NULL,
  `weqweqwl` int(11) NOT NULL,
  `eqweqwk` int(11) NOT NULL,
  `weqwewer` int(11) NOT NULL,
  `qweqweerq` int(11) NOT NULL,
  `qweqwewq` int(11) NOT NULL,
  `qweqwwq` int(11) NOT NULL,
  `ewqeqwewqe` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- -------------------------------------------

-- TABLE `tbl_comment`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_comment`;
CREATE TABLE IF NOT EXISTS `tbl_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `comment` text,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comment_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_comment_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -------------------------------------------

-- TABLE `tbl_email_queue`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_email_queue`;
CREATE TABLE IF NOT EXISTS `tbl_email_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_published` datetime DEFAULT NULL,
  `last_attempt` datetime DEFAULT NULL,
  `date_sent` datetime DEFAULT NULL,
  `attempts` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `model_type` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_account_id` int(11) DEFAULT NULL,
  `message_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_feed`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_feed`;
CREATE TABLE IF NOT EXISTS `tbl_feed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8_unicode_ci,
  `model_type` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_files`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_files`;
CREATE TABLE IF NOT EXISTS `tbl_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8_unicode_ci,
  `model_id` text COLLATE utf8_unicode_ci NOT NULL,
  `model_type` text COLLATE utf8_unicode_ci NOT NULL,
  `target_url` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `filename_user` text COLLATE utf8_unicode_ci NOT NULL,
  `filename_path` text COLLATE utf8_unicode_ci NOT NULL,
  `extension` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `public` int(11) NOT NULL,
  `size` bigint(20) NOT NULL,
  `download_count` bigint(20) DEFAULT '0',
  `file_type` int(11) DEFAULT '1',
  `mimetype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_alt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `updated_by_id` int(11) DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_files_created_by_id` (`created_by_id`),
  KEY `fk_files_updated_by_id` (`updated_by_id`),
  CONSTRAINT `fk_files_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_files_updated_by_id` FOREIGN KEY (`updated_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_language_option`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_language_option`;
CREATE TABLE IF NOT EXISTS `tbl_language_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_language_option_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_language_option_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_logger_log`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_logger_log`;
CREATE TABLE IF NOT EXISTS `tbl_logger_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `error` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `api` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_login_history`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_login_history`;
CREATE TABLE IF NOT EXISTS `tbl_login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `failer_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_media_gallery`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_media_gallery`;
CREATE TABLE IF NOT EXISTS `tbl_media_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `alt` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `thumb_file` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `extension` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  `createBy` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_migration`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_migration`;
CREATE TABLE IF NOT EXISTS `tbl_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- -------------------------------------------

-- TABLE `tbl_notice`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_notice`;
CREATE TABLE IF NOT EXISTS `tbl_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `model_type` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` int(11) NOT NULL,
  `state_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notice_created_by` (`created_by_id`),
  CONSTRAINT `fk_notice_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_notification`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_notification`;
CREATE TABLE IF NOT EXISTS `tbl_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `model_id` int(11) NOT NULL,
  `model_type` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `is_read` tinyint(2) DEFAULT '0',
  `state_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `to_user_id` int(11) DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notification_created_by` (`created_by_id`),
  CONSTRAINT `fk_notification_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_page`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_page`;
CREATE TABLE IF NOT EXISTS `tbl_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_page_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_page_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_queue`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_queue`;
CREATE TABLE IF NOT EXISTS `tbl_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL,
  `job` blob NOT NULL,
  `pushed_at` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `reserved_at` int(11) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `done_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `channel` (`channel`),
  KEY `reserved_at` (`reserved_at`),
  KEY `priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- -------------------------------------------

-- TABLE `tbl_rating`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_rating`;
CREATE TABLE IF NOT EXISTS `tbl_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) NOT NULL,
  `model_type` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `rating` double NOT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_rating_created_by_id` (`created_by_id`),
  CONSTRAINT `FK_rating_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_seo`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_seo`;
CREATE TABLE IF NOT EXISTS `tbl_seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `data` varchar(255) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seo_idx_route` (`route`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -------------------------------------------

-- TABLE `tbl_seo_analytics`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_seo_analytics`;
CREATE TABLE IF NOT EXISTS `tbl_seo_analytics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `domain_name` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `additional_information` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_seo_analytics_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_seo_analytics_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_seo_redirect`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_seo_redirect`;
CREATE TABLE IF NOT EXISTS `tbl_seo_redirect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `old_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `new_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_seo_redirect_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_seo_redirect_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_setting`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_setting`;
CREATE TABLE IF NOT EXISTS `tbl_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `type_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) DEFAULT '0',
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_translator_language`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_translator_language`;
CREATE TABLE IF NOT EXISTS `tbl_translator_language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8_unicode_ci,
  `attribute_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_id` int(11) NOT NULL,
  `model_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_translator_language_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_translator_language_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_user`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` int(11) DEFAULT '0',
  `about_me` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT '0',
  `profile_file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tos` int(11) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT '0',
  `last_visit_time` datetime DEFAULT NULL,
  `last_action_time` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `login_error_count` int(11) DEFAULT NULL,
  `activation_key` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `access_token` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_visitor`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_visitor`;
CREATE TABLE IF NOT EXISTS `tbl_visitor` (
  `id` bigint(20) unsigned NOT NULL,
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visit_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `group_date` int(11) unsigned DEFAULT NULL,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os_version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_model` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




INSERT INTO `tbl_email_queue` (`id`,`from_email`,`to_email`,`message`,`subject`,`date_published`,`last_attempt`,`date_sent`,`attempts`,`state_id`,`model_id`,`model_type`,`email_account_id`,`message_id`) VALUES
("1","admin@toxsl.in","sdf@rty.er","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\">
		<p> Hello		<p>
		Thank you for registering with	 AdminProject.
	 Your login Credentials are	
	<br>
	Email sdf@rty.er	<br>
	Password aaaaaaaa	<br>
		
		<p>Follow the link</p>

		<p><a href=\"http://localhost/yii2-base-admin-panel-api-578/user/login\">http://localhost/yii2-base-admin-panel-api-578/user/login</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Welcome! You new account is ready ToXSL Technologies","2019-11-25 11:37:01","","2019-11-25 11:37:01","","0","","","",""),
("2","admin@toxsl.in","admin@toxsl.in","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/3<br />
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw<br />
Client : ::1<br />
Error : :  Headers already sent.<br />
---------------------<br />
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()<br />
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()<br />
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()<br />
#3 {main}",":  Headers already sent.","2019-11-25 11:37:17","","2019-11-25 11:37:17","","0","","","",""),
("3","admin@toxsl.in","admin@toxsl.in","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/1<br />
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw<br />
Client : ::1<br />
Error : :  Headers already sent.<br />
---------------------<br />
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()<br />
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()<br />
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()<br />
#3 {main}",":  Headers already sent.","2019-11-25 11:37:20","","2019-11-25 11:37:20","","0","","","",""),
("4","admin@toxsl.in","admin@toxsl.in","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/2<br />
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw<br />
Client : ::1<br />
Error : :  Headers already sent.<br />
---------------------<br />
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()<br />
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()<br />
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()<br />
#3 {main}",":  Headers already sent.","2019-11-25 11:37:20","","2019-11-25 11:37:20","","0","","","",""),
("5","admin@toxsl.in","admin@toxsl.in","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/3<br />
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw<br />
Client : ::1<br />
Error : :  Headers already sent.<br />
---------------------<br />
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()<br />
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()<br />
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()<br />
#3 {main}",":  Headers already sent.","2019-11-25 11:37:43","","2019-11-25 11:37:43","","0","","","",""),
("6","admin@toxsl.in","admin@toxsl.in","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/2<br />
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw<br />
Client : ::1<br />
Error : :  Headers already sent.<br />
---------------------<br />
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()<br />
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()<br />
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()<br />
#3 {main}",":  Headers already sent.","2019-11-25 11:37:44","","2019-11-25 11:37:44","","0","","","",""),
("7","admin@toxsl.in","admin@toxsl.in","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/1<br />
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw<br />
Client : ::1<br />
Error : :  Headers already sent.<br />
---------------------<br />
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()<br />
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()<br />
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()<br />
#3 {main}",":  Headers already sent.","2019-11-25 11:37:44","","2019-11-25 11:37:44","","0","","","",""),
("8","admin@toxsl.in","admin@toxsl.in","Url : http://localhost/yii2-base-admin-panel-api-578Changes/user/login<br />
Referer : <br />
Client : ::1<br />
Error : :  The directory is not writable by the Web process: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/assets<br />
---------------------<br />
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/AssetBundle.php(185): yii\\web\\AssetManager->publish(\'/home/local/TOX...\', Array)<br />
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/AssetManager.php(266): yii\\web\\AssetBundle->publish(Object(yii\\web\\AssetManager))<br />
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/AssetManager.php(237): yii\\web\\AssetManager->loadBundle(\'yii\\\\widgets\\\\Act...\', Array, true)<br />
#3 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/View.php(287): yii\\web\\AssetManager->getBundle(\'yii\\\\widgets\\\\Act...\')<br />
#4 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/AssetBundle.php(125): yii\\web\\View->registerAssetBundle(\'yii\\\\widgets\\\\Act...\')<br />
#5 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/widgets/ActiveForm.php(245): yii\\web\\AssetBundle::register(Object(yii\\web\\View))<br />
#6 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/widgets/ActiveForm.php(228): yii\\widgets\\ActiveForm->registerClientScript()<br />
#7 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/Widget.php(109): yii\\widgets\\ActiveForm->run()<br />
#8 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/protected/views/user/login.php(117): yii\\base\\Widget::end()<br />
#9 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/View.php(348): require(\'/home/local/TOX...\')<br />
#10 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/View.php(257): yii\\base\\View->renderPhpFile(\'/home/local/TOX...\', Array)<br />
#11 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/View.php(156): yii\\base\\View->renderFile(\'/home/local/TOX...\', Array, Object(app\\controllers\\UserController))<br />
#12 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/Controller.php(386): yii\\base\\View->render(\'login\', Array, Object(app\\controllers\\UserController))<br />
#13 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/protected/components/TController.php(394): yii\\base\\Controller->render(\'login\', Array)<br />
#14 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/protected/controllers/UserController.php(456): app\\components\\TController->render(\'login\', Array)<br />
#15 [internal function]: app\\controllers\\UserController->actionLogin()<br />
#16 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)<br />
#17 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/Controller.php(157): yii\\base\\InlineAction->runWithParams(Array)<br />
#18 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/Module.php(528): yii\\base\\Controller->runAction(\'login\', Array)<br />
#19 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/Application.php(103): yii\\base\\Module->runAction(\'user/login\', Array)<br />
#20 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/Application.php(386): yii\\web\\Application->handleRequest(Object(app\\components\\TRequest))<br />
#21 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/index.php(10): yii\\base\\Application->run()<br />
#22 {main}",":  The directory is not writable by the Web process: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/assets","2019-11-27 10:59:26","","2019-11-27 10:59:26","","0","","","",""),
("9","admin@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=jkCqDeGKGuvIGNALjwDeB0rZ-PLbj78h_1574837235\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=jkCqDeGKGuvIGNALjwDeB0rZ-PLbj78h_1574837235								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Welcome! You new account is ready ToXSL Technologies","2019-11-27 12:17:15","","2019-11-27 12:17:15","","0","","","",""),
("10","Trand164est@341String.com","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=jkCqDeGKGuvIGNALjwDeB0rZ-PLbj78h_1574837235\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=jkCqDeGKGuvIGNALjwDeB0rZ-PLbj78h_1574837235								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New User Registerd Successfully","2019-11-27 12:17:16","","2019-11-27 12:17:16","","0","","","",""),
("11","admin@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=DUx_umSYLwr1T-IIBw_ILGYsvmA9Gc_Y_1574837695\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=DUx_umSYLwr1T-IIBw_ILGYsvmA9Gc_Y_1574837695								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Welcome! You new account is ready ToXSL Technologies","2019-11-27 12:24:55","","2019-11-27 12:24:55","","0","","","",""),
("12","Trand164est@341String.coms","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=DUx_umSYLwr1T-IIBw_ILGYsvmA9Gc_Y_1574837695\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=DUx_umSYLwr1T-IIBw_ILGYsvmA9Gc_Y_1574837695								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New User Registerd Successfully","2019-11-27 12:24:55","","2019-11-27 12:24:55","","0","","","",""),
("13","admin@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=exZWewA0XCpQWK_27zUfHkXymAeaDSyn_1574837710\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=exZWewA0XCpQWK_27zUfHkXymAeaDSyn_1574837710								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Welcome! You new account is ready ToXSL Technologies","2019-11-27 12:25:10","","2019-11-27 12:25:10","","0","","","",""),
("14","Trand164est@341String.comsd","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=exZWewA0XCpQWK_27zUfHkXymAeaDSyn_1574837710\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=exZWewA0XCpQWK_27zUfHkXymAeaDSyn_1574837710								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New User Registerd Successfully","2019-11-27 12:25:10","","2019-11-27 12:25:10","","0","","","",""),
("15","admin@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=SPhHaPWOdR6jQWSBD7E3AgPOJpV_V8yT_1574837874\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=SPhHaPWOdR6jQWSBD7E3AgPOJpV_V8yT_1574837874								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Welcome! You new account is ready ToXSL Technologies","2019-11-27 12:27:54","","2019-11-27 12:27:54","","0","","","",""),
("16","wrTrand164est@341String.comsdertasdasd","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=SPhHaPWOdR6jQWSBD7E3AgPOJpV_V8yT_1574837874\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=SPhHaPWOdR6jQWSBD7E3AgPOJpV_V8yT_1574837874								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New User Registerd Successfully","2019-11-27 12:27:54","","2019-11-27 12:27:54","","0","","","",""),
("17","admin@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=XZhFaEMC2tHlNSOwWNaygpt4Jf0awIKM_1574837888\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=XZhFaEMC2tHlNSOwWNaygpt4Jf0awIKM_1574837888								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Welcome! You new account is ready ToXSL Technologies","2019-11-27 12:28:08","","2019-11-27 12:28:08","","0","","","",""),
("18","wrTrand164est@341String.comsdertasdasdasd","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=XZhFaEMC2tHlNSOwWNaygpt4Jf0awIKM_1574837888\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=XZhFaEMC2tHlNSOwWNaygpt4Jf0awIKM_1574837888								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New User Registerd Successfully","2019-11-27 12:28:08","","2019-11-27 12:28:08","","0","","","",""),
("19","admin@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=ucv_kMoZBV1OrW0tKtwginpIX2X4ZJTV_1574838056\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=ucv_kMoZBV1OrW0tKtwginpIX2X4ZJTV_1574838056								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Welcome! You new account is ready ToXSL Technologies","2019-11-27 12:30:56","","2019-11-27 12:30:56","","0","","","",""),
("20","qwewrTrand164est@341String.comsdertasdasdasd","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=ucv_kMoZBV1OrW0tKtwginpIX2X4ZJTV_1574838056\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=ucv_kMoZBV1OrW0tKtwginpIX2X4ZJTV_1574838056								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New User Registerd Successfully","2019-11-27 12:30:57","","2019-11-27 12:30:57","","0","","","",""),
("21","admin@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=WrFNgz2DfopJxjRApJ_gokk8cyf0RbP9_1574838070\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=WrFNgz2DfopJxjRApJ_gokk8cyf0RbP9_1574838070								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Welcome! You new account is ready ToXSL Technologies","2019-11-27 12:31:10","","2019-11-27 12:31:10","","0","","","",""),
("22","qwewrTrand164est@341String.comsdertasdasdasdasd","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=WrFNgz2DfopJxjRApJ_gokk8cyf0RbP9_1574838070\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=WrFNgz2DfopJxjRApJ_gokk8cyf0RbP9_1574838070								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New User Registerd Successfully","2019-11-27 12:31:10","","2019-11-27 12:31:10","","0","","","",""),
("23","admin@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=5dxzMvYeP5EVYu_1kPAF0sFtsCBKgS8P_1574838111\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=5dxzMvYeP5EVYu_1kPAF0sFtsCBKgS8P_1574838111								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Welcome! You new account is ready ToXSL Technologies","2019-11-27 12:31:51","","2019-11-27 12:31:51","","0","","","",""),
("24","qwewrTrand164est@341String.comsdertasdasdasdasdweqq","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=5dxzMvYeP5EVYu_1kPAF0sFtsCBKgS8P_1574838111\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578Changes/user/confirm-email?id=5dxzMvYeP5EVYu_1kPAF0sFtsCBKgS8P_1574838111								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New User Registerd Successfully","2019-11-27 12:31:51","","2019-11-27 12:31:51","","0","","","",""),
("25","admin@toxsl.in","admin@toxsl.in","Url : http://localhost/yii2-base-admin-panel-api-578/<br />
Referer : <br />
Client : ::1<br />
Error : :  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard.php<br />
---------------------<br />
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/View.php(156): yii\\base\\View->renderFile(\'/home/local/TOX...\', Array, Object(app\\controllers\\SiteController))<br />
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(386): yii\\base\\View->render(\'/dashboard\', Array, Object(app\\controllers\\SiteController))<br />
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/components/TController.php(394): yii\\base\\Controller->render(\'/dashboard\', Array)<br />
#3 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/controllers/SiteController.php(87): app\\components\\TController->render(\'/dashboard\')<br />
#4 [internal function]: app\\controllers\\SiteController->actionIndex()<br />
#5 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)<br />
#6 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(157): yii\\base\\InlineAction->runWithParams(Array)<br />
#7 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Module.php(528): yii\\base\\Controller->runAction(\'\', Array)<br />
#8 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Application.php(103): yii\\base\\Module->runAction(\'\', Array)<br />
#9 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(386): yii\\web\\Application->handleRequest(Object(app\\components\\TRequest))<br />
#10 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()<br />
#11 {main}",":  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard.php","2019-11-27 01:13:21","","2019-11-27 13:13:21","","0","","","",""),
("26","admin@toxsl.in","admin@toxsl.in","Url : http://localhost/yii2-base-admin-panel-api-578/<br />
Referer : <br />
Client : ::1<br />
Error : :  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard.php<br />
---------------------<br />
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/View.php(156): yii\\base\\View->renderFile(\'/home/local/TOX...\', Array, Object(app\\controllers\\SiteController))<br />
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(386): yii\\base\\View->render(\'/dashboard\', Array, Object(app\\controllers\\SiteController))<br />
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/components/TController.php(394): yii\\base\\Controller->render(\'/dashboard\', Array)<br />
#3 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/controllers/SiteController.php(87): app\\components\\TController->render(\'/dashboard\')<br />
#4 [internal function]: app\\controllers\\SiteController->actionIndex()<br />
#5 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)<br />
#6 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(157): yii\\base\\InlineAction->runWithParams(Array)<br />
#7 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Module.php(528): yii\\base\\Controller->runAction(\'\', Array)<br />
#8 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Application.php(103): yii\\base\\Module->runAction(\'\', Array)<br />
#9 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(386): yii\\web\\Application->handleRequest(Object(app\\components\\TRequest))<br />
#10 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()<br />
#11 {main}",":  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard.php","2019-11-27 01:13:28","","2019-11-27 13:13:28","","0","","","",""),
("27","admin@toxsl.in","admin@toxsl.in","Url : http://localhost/yii2-base-admin-panel-api-578/<br />
Referer : <br />
Client : ::1<br />
Error : :  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard/.php<br />
---------------------<br />
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/View.php(156): yii\\base\\View->renderFile(\'/home/local/TOX...\', Array, Object(app\\controllers\\SiteController))<br />
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(386): yii\\base\\View->render(\'/dashboard/\', Array, Object(app\\controllers\\SiteController))<br />
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/components/TController.php(394): yii\\base\\Controller->render(\'/dashboard/\', Array)<br />
#3 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/controllers/SiteController.php(87): app\\components\\TController->render(\'/dashboard/\')<br />
#4 [internal function]: app\\controllers\\SiteController->actionIndex()<br />
#5 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)<br />
#6 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(157): yii\\base\\InlineAction->runWithParams(Array)<br />
#7 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Module.php(528): yii\\base\\Controller->runAction(\'\', Array)<br />
#8 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Application.php(103): yii\\base\\Module->runAction(\'\', Array)<br />
#9 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(386): yii\\web\\Application->handleRequest(Object(app\\components\\TRequest))<br />
#10 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()<br />
#11 {main}",":  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard/.php","2019-11-27 01:13:43","","2019-11-27 13:13:43","","0","","","",""),
("28","admin@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578/user/confirm-email?id=Vxq1aRAhsyRaxIjk77QXnzghK1KAWkZW_1574841244\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578/user/confirm-email?id=Vxq1aRAhsyRaxIjk77QXnzghK1KAWkZW_1574841244								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Welcome! You new account is ready ToXSL Technologies","2019-11-27 01:24:04","","2019-11-27 13:24:04","","0","","","",""),
("29","Trand478est@38String.com1","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578/user/confirm-email?id=Vxq1aRAhsyRaxIjk77QXnzghK1KAWkZW_1574841244\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578/user/confirm-email?id=Vxq1aRAhsyRaxIjk77QXnzghK1KAWkZW_1574841244								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New User Registerd Successfully","2019-11-27 01:24:05","","2019-11-27 13:24:05","","0","","","",""),
("30","admin@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578/user/confirm-email?id=tjrCUsocXKgdySx-YePQ2U_Dg4DSgvw0_1574841775\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578/user/confirm-email?id=tjrCUsocXKgdySx-YePQ2U_Dg4DSgvw0_1574841775								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Welcome! You new account is ready ToXSL Technologies","2019-11-27 01:32:56","","2019-11-27 13:32:56","","0","","","",""),
("31","Trand302est@253String.com","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">AdminProject</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td colspan=\"2\" style=\"padding: 30px 0;\">
		<p
			style=\"color: #1d2227; line-height: 28px; font-size: 25px; margin: 12px 10px 16px 10px; font-weight: 400;\">Welcome
			to AdminProject</p>
		<p style=\"margin: 0 10px 10px 10px; padding: 0; font-size: 14px;\">
			Thanks for signing up. To send your first ToXSL Technologies, please verify<br>
			your email address by clicking the button below.
		</p>
		<p>
			<a
				style=\"display: inline-block; text-decoration: none; padding: 11px 20px; background-color: #6dbd63; border: 1px solid #6dbd63; border-radius: 3px; color: #FFF; font-weight: bold;\"
				href=\"http://localhost/yii2-base-admin-panel-api-578/user/confirm-email?id=tjrCUsocXKgdySx-YePQ2U_Dg4DSgvw0_1574841775\" target=\"_blank\">Activate your account and
				log in</a>
		</p>
		<p>
			<font size=\"2\" color=\"#333\"> If above link isn\'t working, please copy
				and paste it directly in you browser\'s URL field to get started.<br />
				<br />
	                          
	                              http://localhost/yii2-base-admin-panel-api-578/user/confirm-email?id=tjrCUsocXKgdySx-YePQ2U_Dg4DSgvw0_1574841775								</font>
		</p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>AdminProject Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; AdminProject</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New User Registerd Successfully","2019-11-27 01:32:56","","2019-11-27 13:32:56","","0","","","","");

 -- -------AutobackUpStart------ 


INSERT INTO `tbl_feed` (`id`,`content`,`model_type`,`model_id`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578/user/view/1/super-admin\">Super Admin</a>","app\\models\\User","1","1","0","2019-11-21 21:07:48","2019-11-21 21:07:48",""),
("2","Added new Setting : <a href=\"http://localhost/yii2-base-admin-panel-api-578/setting/view/1/app-configration\">App Configration</a>","app\\models\\Setting","1","1","0","2019-11-21 21:07:48","2019-11-21 21:07:48","1"),
("3","Added new Setting : <a href=\"http://localhost/yii2-base-admin-panel-api-578/setting/view/2/smtp-configration\">SMTP Configration</a>","app\\models\\Setting","2","1","0","2019-11-21 21:07:48","2019-11-21 21:07:48","1"),
("4","Added new Setting : <a href=\"http://localhost/yii2-base-admin-panel-api-578/setting/view/3/firebase-configration\">Firebase Configration</a>","app\\models\\Setting","3","1","0","2019-11-21 21:07:48","2019-11-21 21:07:48","1"),
("5","Added new Login History : <a href=\"http://localhost/yii2-base-admin-panel-api-578/login-history/view/1/1\">1</a>","app\\models\\LoginHistory","1","1","0","2019-11-25 11:36:40","2019-11-25 11:36:40",""),
("6","Added new Login History : <a href=\"http://localhost/yii2-base-admin-panel-api-578/login-history/view/2/1\">1</a>","app\\models\\LoginHistory","2","1","0","2019-11-25 11:36:44","2019-11-25 11:36:44",""),
("7","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw\">ewrw</a>","app\\models\\User","2","1","0","2019-11-25 11:37:02","2019-11-25 11:37:02","1"),
("8","Added new File : <a href=\"http://localhost/yii2-base-admin-panel-api-578/file/file/view/1\">File</a>","app\\modules\\file\\models\\File","1","1","0","2019-11-25 11:37:14","2019-11-25 11:37:14","1"),
("9","Added new File : <a href=\"http://localhost/yii2-base-admin-panel-api-578/file/file/view/2\">File</a>","app\\modules\\file\\models\\File","2","1","0","2019-11-25 11:37:14","2019-11-25 11:37:14","1"),
("10","Added new File : <a href=\"http://localhost/yii2-base-admin-panel-api-578/file/file/view/3\">File</a>","app\\modules\\file\\models\\File","3","1","0","2019-11-25 11:37:14","2019-11-25 11:37:14","1"),
("11","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/view/3/test-string\">Test String</a>","app\\models\\User","3","1","0","2019-11-27 11:16:00","2019-11-27 11:16:00",""),
("12","Added new Login History : <a href=\"http://localhost/yii2-base-admin-panel-api-578Changes/login-history/view/3/1\">1</a>","app\\models\\LoginHistory","3","1","0","2019-11-27 11:43:19","2019-11-27 11:43:19",""),
("13","Added new Login History : <a href=\"http://localhost/yii2-base-admin-panel-api-578Changes/login-history/view/4/1\">1</a>","app\\models\\LoginHistory","4","1","0","2019-11-27 11:43:24","2019-11-27 11:43:24",""),
("14","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/view/4/test-string\">Test String</a>","app\\models\\User","4","1","0","2019-11-27 12:17:15","2019-11-27 12:17:15",""),
("15","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/view/5/test-string\">Test String</a>","app\\models\\User","5","1","0","2019-11-27 12:24:55","2019-11-27 12:24:55",""),
("16","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/view/6/test-string\">Test String</a>","app\\models\\User","6","1","0","2019-11-27 12:25:10","2019-11-27 12:25:10",""),
("17","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/view/7/test-string\">Test String</a>","app\\models\\User","7","1","0","2019-11-27 12:27:54","2019-11-27 12:27:54",""),
("18","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/view/8/test-string\">Test String</a>","app\\models\\User","8","1","0","2019-11-27 12:28:08","2019-11-27 12:28:08",""),
("19","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/view/9/test-string\">Test String</a>","app\\models\\User","9","1","0","2019-11-27 12:30:56","2019-11-27 12:30:56",""),
("20","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/view/10/test-string\">Test String</a>","app\\models\\User","10","1","0","2019-11-27 12:31:10","2019-11-27 12:31:10",""),
("21","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578Changes/user/view/11/test-string\">Test String</a>","app\\models\\User","11","1","0","2019-11-27 12:31:51","2019-11-27 12:31:51",""),
("22","Added new Login History : <a href=\"http://localhost/yii2-base-admin-panel-api-578/login-history/view/5/1\">1</a>","app\\models\\LoginHistory","5","1","0","2019-11-27 13:12:38","2019-11-27 13:12:38",""),
("23","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578/user/view/12/test-string\">Test String</a>","app\\models\\User","12","1","0","2019-11-27 13:24:04","2019-11-27 13:24:04",""),
("24","Added new User : <a href=\"http://localhost/yii2-base-admin-panel-api-578/user/view/13/test-string\">Test String</a>","app\\models\\User","13","1","0","2019-11-27 13:32:55","2019-11-27 13:32:55",""),
("25","Added new Login History : <a href=\"http://localhost/yii2-base-admin-panel-api-578/login-history/view/6/1\">1</a>","app\\models\\LoginHistory","6","1","0","2019-11-28 11:46:16","2019-11-28 11:46:16",""),
("26","Added new Login History : <a href=\"http://localhost/yii2-base-admin-panel-api-578/login-history/view/7/1\">1</a>","app\\models\\LoginHistory","7","1","0","2019-11-28 11:46:20","2019-11-28 11:46:20",""),
("27","Added new Login History : <a href=\"http://localhost/yii2-base-admin-panel-api-578/login-history/view/8/1\">1</a>","app\\models\\LoginHistory","8","1","0","2019-12-02 11:00:08","2019-12-02 11:00:08",""),
("28","Added new Login History : <a href=\"http://localhost/yii2-base-admin-panel-api-578/login-history/view/9/1\">1</a>","app\\models\\LoginHistory","9","1","0","2019-12-13 15:27:55","2019-12-13 15:27:55",""),
("29","Added new File : <a href=\"http://localhost/yii2-base-admin-panel-api-578/file/file/view/4\">File</a>","app\\modules\\file\\models\\File","4","1","0","2019-12-13 15:28:28","2019-12-13 15:28:28","1");

 -- -------AutobackUpStart------ 


INSERT INTO `tbl_files` (`id`,`title`,`model_id`,`model_type`,`target_url`,`description`,`filename_user`,`filename_path`,`extension`,`public`,`size`,`download_count`,`file_type`,`mimetype`,`seo_title`,`seo_alt`,`state_id`,`type_id`,`created_on`,`updated_on`,`updated_by_id`,`created_by_id`) VALUES
("1","","2","app\\models\\User","/yii2-base-admin-panel-api-578/user/2","","01 - February 2019 _myphotopack.com_.jpg","9c80b187829a1775c4b90f78f65e3c7d-01 - February 2019 _myphotopack.com_.jpg","jpg","1","2509259","2","1","image/jpeg","","","1","0","2019-11-25 11:37:14","2019-11-25 11:37:14","","1"),
("2","","2","app\\models\\User","/yii2-base-admin-panel-api-578/user/2","","02 - February 2019 _myphotopack.com_.jpg","00a243d1f782c7c35b1579d155ab2ee9-02 - February 2019 _myphotopack.com_.jpg","jpg","1","2923639","2","1","image/jpeg","","","1","0","2019-11-25 11:37:14","2019-11-25 11:37:14","","1"),
("3","","2","app\\models\\User","/yii2-base-admin-panel-api-578/user/2","","03 - February 2019 _myphotopack.com_.jpg","891ae932d67b8f8268d40ba51eb90284-03 - February 2019 _myphotopack.com_.jpg","jpg","1","1724974","2","1","image/jpeg","","","1","0","2019-11-25 11:37:14","2019-11-25 11:37:14","","1"),
("4","","13","app\\models\\User","/yii2-base-admin-panel-api-578/user/13","","pretty-print-json-master.zip","c96d846cae94808f3a7e109f953d6425-pretty-print-json-master.zip","zip","1","17076","0","1","application/zip","","","1","0","2019-12-13 15:28:28","2019-12-13 15:28:28","","1");

 -- -------AutobackUpStart------ 


INSERT INTO `tbl_logger_log` (`id`,`error`,`api`,`description`,`state_id`,`link`,`type_id`,`created_on`) VALUES
("1",":  Headers already sent.","","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/3
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw
Client : ::1
Error : :  Headers already sent.
---------------------
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()
#3 {main}","1","http://localhost/yii2-base-admin-panel-api-578/file/file/download/3","0","2019-11-25 11:37:17"),
("2",":  Headers already sent.","","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/1
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw
Client : ::1
Error : :  Headers already sent.
---------------------
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()
#3 {main}","1","http://localhost/yii2-base-admin-panel-api-578/file/file/download/1","0","2019-11-25 11:37:20"),
("3",":  Headers already sent.","","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/2
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw
Client : ::1
Error : :  Headers already sent.
---------------------
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()
#3 {main}","1","http://localhost/yii2-base-admin-panel-api-578/file/file/download/2","0","2019-11-25 11:37:20"),
("4",":  Headers already sent.","","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/3
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw
Client : ::1
Error : :  Headers already sent.
---------------------
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()
#3 {main}","1","http://localhost/yii2-base-admin-panel-api-578/file/file/download/3","0","2019-11-25 11:37:43"),
("5",":  Headers already sent.","","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/2
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw
Client : ::1
Error : :  Headers already sent.
---------------------
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()
#3 {main}","1","http://localhost/yii2-base-admin-panel-api-578/file/file/download/2","0","2019-11-25 11:37:44"),
("6",":  Headers already sent.","","Url : http://localhost/yii2-base-admin-panel-api-578/file/file/download/1
Referer : http://localhost/yii2-base-admin-panel-api-578/user/view/2/ewrw
Client : ::1
Error : :  Headers already sent.
---------------------
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Response.php(339): yii\\web\\Response->sendHeaders()
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(392): yii\\web\\Response->send()
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()
#3 {main}","1","http://localhost/yii2-base-admin-panel-api-578/file/file/download/1","0","2019-11-25 11:37:44"),
("7",":  The directory is not writable by the Web process: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/assets","","Url : http://localhost/yii2-base-admin-panel-api-578Changes/user/login
Referer : 
Client : ::1
Error : :  The directory is not writable by the Web process: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/assets
---------------------
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/AssetBundle.php(185): yii\\web\\AssetManager->publish(\'/home/local/TOX...\', Array)
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/AssetManager.php(266): yii\\web\\AssetBundle->publish(Object(yii\\web\\AssetManager))
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/AssetManager.php(237): yii\\web\\AssetManager->loadBundle(\'yii\\\\widgets\\\\Act...\', Array, true)
#3 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/View.php(287): yii\\web\\AssetManager->getBundle(\'yii\\\\widgets\\\\Act...\')
#4 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/AssetBundle.php(125): yii\\web\\View->registerAssetBundle(\'yii\\\\widgets\\\\Act...\')
#5 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/widgets/ActiveForm.php(245): yii\\web\\AssetBundle::register(Object(yii\\web\\View))
#6 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/widgets/ActiveForm.php(228): yii\\widgets\\ActiveForm->registerClientScript()
#7 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/Widget.php(109): yii\\widgets\\ActiveForm->run()
#8 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/protected/views/user/login.php(117): yii\\base\\Widget::end()
#9 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/View.php(348): require(\'/home/local/TOX...\')
#10 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/View.php(257): yii\\base\\View->renderPhpFile(\'/home/local/TOX...\', Array)
#11 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/View.php(156): yii\\base\\View->renderFile(\'/home/local/TOX...\', Array, Object(app\\controllers\\UserController))
#12 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/Controller.php(386): yii\\base\\View->render(\'login\', Array, Object(app\\controllers\\UserController))
#13 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/protected/components/TController.php(394): yii\\base\\Controller->render(\'login\', Array)
#14 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/protected/controllers/UserController.php(456): app\\components\\TController->render(\'login\', Array)
#15 [internal function]: app\\controllers\\UserController->actionLogin()
#16 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)
#17 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/Controller.php(157): yii\\base\\InlineAction->runWithParams(Array)
#18 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/Module.php(528): yii\\base\\Controller->runAction(\'login\', Array)
#19 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/web/Application.php(103): yii\\base\\Module->runAction(\'user/login\', Array)
#20 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/vendor/yiisoft/yii2/base/Application.php(386): yii\\web\\Application->handleRequest(Object(app\\components\\TRequest))
#21 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578Changes/index.php(10): yii\\base\\Application->run()
#22 {main}","1","http://localhost/yii2-base-admin-panel-api-578Changes/user/login","0","2019-11-27 10:59:25"),
("8",":  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard.php","","Url : http://localhost/yii2-base-admin-panel-api-578/
Referer : 
Client : ::1
Error : :  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard.php
---------------------
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/View.php(156): yii\\base\\View->renderFile(\'/home/local/TOX...\', Array, Object(app\\controllers\\SiteController))
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(386): yii\\base\\View->render(\'/dashboard\', Array, Object(app\\controllers\\SiteController))
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/components/TController.php(394): yii\\base\\Controller->render(\'/dashboard\', Array)
#3 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/controllers/SiteController.php(87): app\\components\\TController->render(\'/dashboard\')
#4 [internal function]: app\\controllers\\SiteController->actionIndex()
#5 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)
#6 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(157): yii\\base\\InlineAction->runWithParams(Array)
#7 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Module.php(528): yii\\base\\Controller->runAction(\'\', Array)
#8 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Application.php(103): yii\\base\\Module->runAction(\'\', Array)
#9 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(386): yii\\web\\Application->handleRequest(Object(app\\components\\TRequest))
#10 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()
#11 {main}","1","http://localhost/yii2-base-admin-panel-api-578/","0","2019-11-27 13:13:21"),
("9",":  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard.php","","Url : http://localhost/yii2-base-admin-panel-api-578/
Referer : 
Client : ::1
Error : :  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard.php
---------------------
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/View.php(156): yii\\base\\View->renderFile(\'/home/local/TOX...\', Array, Object(app\\controllers\\SiteController))
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(386): yii\\base\\View->render(\'/dashboard\', Array, Object(app\\controllers\\SiteController))
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/components/TController.php(394): yii\\base\\Controller->render(\'/dashboard\', Array)
#3 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/controllers/SiteController.php(87): app\\components\\TController->render(\'/dashboard\')
#4 [internal function]: app\\controllers\\SiteController->actionIndex()
#5 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)
#6 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(157): yii\\base\\InlineAction->runWithParams(Array)
#7 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Module.php(528): yii\\base\\Controller->runAction(\'\', Array)
#8 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Application.php(103): yii\\base\\Module->runAction(\'\', Array)
#9 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(386): yii\\web\\Application->handleRequest(Object(app\\components\\TRequest))
#10 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()
#11 {main}","1","http://localhost/yii2-base-admin-panel-api-578/","0","2019-11-27 13:13:28"),
("10",":  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard/.php","","Url : http://localhost/yii2-base-admin-panel-api-578/
Referer : 
Client : ::1
Error : :  The view file does not exist: /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/views/dashboard/.php
---------------------
#0 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/View.php(156): yii\\base\\View->renderFile(\'/home/local/TOX...\', Array, Object(app\\controllers\\SiteController))
#1 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(386): yii\\base\\View->render(\'/dashboard/\', Array, Object(app\\controllers\\SiteController))
#2 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/components/TController.php(394): yii\\base\\Controller->render(\'/dashboard/\', Array)
#3 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/protected/controllers/SiteController.php(87): app\\components\\TController->render(\'/dashboard/\')
#4 [internal function]: app\\controllers\\SiteController->actionIndex()
#5 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)
#6 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Controller.php(157): yii\\base\\InlineAction->runWithParams(Array)
#7 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Module.php(528): yii\\base\\Controller->runAction(\'\', Array)
#8 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/web/Application.php(103): yii\\base\\Module->runAction(\'\', Array)
#9 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/vendor/yiisoft/yii2/base/Application.php(386): yii\\web\\Application->handleRequest(Object(app\\components\\TRequest))
#10 /home/local/TOXSL/naresh.saini/html/yii2-base-admin-panel-api-578/index.php(10): yii\\base\\Application->run()
#11 {main}","1","http://localhost/yii2-base-admin-panel-api-578/","0","2019-11-27 13:13:43");

 -- -------AutobackUpStart------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("1","1","::1","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/75.0.3770.90 Chrome/75.0.3770.90 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://localhost/yii2-base-admin-panel-api-578/user/login","2019-11-25 11:36:40"),
("2","1","::1","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/75.0.3770.90 Chrome/75.0.3770.90 Safari/537.36","","1","0","http://localhost/yii2-base-admin-panel-api-578/user/login","2019-11-25 11:36:44"),
("3","1","::1","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://localhost/yii2-base-admin-panel-api-578Changes/user/login","2019-11-27 11:43:19"),
("4","1","::1","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36","","1","0","http://localhost/yii2-base-admin-panel-api-578Changes/user/login","2019-11-27 11:43:23"),
("5","1","::1","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36","","1","0","http://localhost/yii2-base-admin-panel-api-578/user/login","2019-11-27 13:12:38"),
("6","1","::1","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/75.0.3770.90 Chrome/75.0.3770.90 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://localhost/yii2-base-admin-panel-api-578/user/login","2019-11-28 11:46:15"),
("7","1","::1","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/75.0.3770.90 Chrome/75.0.3770.90 Safari/537.36","","1","0","http://localhost/yii2-base-admin-panel-api-578/user/login","2019-11-28 11:46:20"),
("8","1","::1","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/75.0.3770.90 Chrome/75.0.3770.90 Safari/537.36","","1","0","http://localhost/yii2-base-admin-panel-api-578/user/login","2019-12-02 11:00:08"),
("9","1","::1","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/75.0.3770.90 Chrome/75.0.3770.90 Safari/537.36","","1","0","http://localhost/yii2-base-admin-panel-api-578/user/login","2019-12-13 15:27:55");

 -- -------AutobackUpStart------ 


INSERT INTO `tbl_setting` (`id`,`key`,`title`,`value`,`type_id`,`state_id`,`created_by_id`) VALUES
("1","appConfig","App Configration","{\"companyUrl\":{\"type\":0,\"value\":\"https://www.toxsl.com\",\"required\":true},\"company\":{\"type\":0,\"value\":\"ToXSL Technologies\",\"required\":true},\"companyEmail\":{\"type\":0,\"value\":\"admin@toxsl.in\",\"required\":true},\"companyContactEmail\":{\"type\":0,\"value\":\"admin@toxsl.in\",\"required\":false},\"companyContactNo\":{\"type\":0,\"value\":\"9569127788\",\"required\":false},\"companyAddress\":{\"type\":0,\"value\":\"C-127, 2nd floor, Phase 8, Industrial Area, Sector 72, Mohali, Punjab\",\"required\":false},\"loginCount\":{\"type\":2,\"value\":2,\"required\":false}}","","0","1"),
("2","smtp","SMTP Configration","{\"host\":{\"type\":0,\"value\":\"\",\"required\":true},\"username\":{\"type\":0,\"value\":\"\",\"required\":true},\"password\":{\"type\":0,\"value\":\"\",\"required\":true},\"port\":{\"type\":0,\"value\":\"\",\"required\":true},\"encryption\":{\"type\":0,\"value\":\"\",\"required\":false}}","","0","1"),
("3","firebaseSettings","Firebase Configration","{\"authKey\":{\"type\":0,\"value\":\"\",\"required\":true}}","","0","1");

 -- -------AutobackUpStart------ 


INSERT INTO `tbl_user` (`id`,`full_name`,`email`,`password`,`date_of_birth`,`gender`,`about_me`,`contact_no`,`address`,`latitude`,`longitude`,`city`,`country`,`zipcode`,`language`,`email_verified`,`profile_file`,`tos`,`role_id`,`state_id`,`type_id`,`last_visit_time`,`last_action_time`,`last_password_change`,`login_error_count`,`activation_key`,`access_token`,`timezone`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","Super Admin","admin@toxsl.in","$2y$13$4UkoT0obL9xYMUnaqIhqBeAVuAPdqKBmltwNpi6gSJzePQo2sRLvu","","0","","","","","","","","","","0","","","0","1","0","2019-12-23 09:56:09","","","","V8WhyS5kNLoL0My7fnquAkCHaFELjgnd_1574350667","mPqjNyNaHf-_E7V6OlvrHRrl_32pvG8B","","2019-11-21 21:07:47","2019-11-21 21:07:47",""),
("2","ewrw","sdf@rty.er","$2y$13$vqJVZB6wWR3GhWJ2oDZ6Zet0z1SRZdM3VXTUnDyPeNONiKUq52kIm","","0","","","","","","","","","","0","","","1","1","0","2019-11-27 11:46:15","","","","hixkACZ6RjMXQ36RV7fXpct270jOZi-K_1574662021","CFh3LlIQ8K4t2dugrIMTL9x9OESBOFca","","2019-11-25 11:37:01","2019-11-25 11:37:01","1"),
("3","Test String","Trand78est@169String.com","$2y$13$Hpk1OEiUfqEsKjToCfnU4uCjPeXCxcB0bW37Ehodj/xQAECzjxcjm","","0","","Test String","","","","","","","","0","","","2","1","0","2019-11-27 11:46:09","","","","NfPVT5a0NRR4i8bi888e0T3h1K_HvjVV_1574833560","myqdj6KMSjX0a8p0pmpKlmfRV2RQ7DQf","","2019-11-27 11:16:00","2019-11-27 11:16:00",""),
("12","Test String","Trand478est@38String.com1","$2y$13$UaEYxV2Biysygp2FVXJdoeF/xyl05xSORAqA.qWd67Q0Fv9ipKPVm","","0","","Test String","","","","","","","","0","","","2","1","0","2019-11-27 13:29:25","","","","Vxq1aRAhsyRaxIjk77QXnzghK1KAWkZW_1574841244","raKQ2lJEeAoMvdzuW9rRW5gEl3tK0E8W","","2019-11-27 13:24:04","2019-11-27 13:24:04",""),
("13","Test String","Trand302est@253String.com","$2y$13$4Y2DrQGYy.5jDn832AFrEepsgFNH8ynO49F7lR5UIC6T6WmrJKda6","","0","","Test String","","","","","","","","0","","","2","1","0","2019-11-27 13:55:01","","","","tjrCUsocXKgdySx-YePQ2U_Dg4DSgvw0_1574841775","n-87etc2pFIbYutqaMs0tN8cf3nF7Fqw","","2019-11-27 13:32:55","2019-11-27 13:32:55","");

 -- -------AutobackUpStart------ 
COMMIT;
-- -------------------------------------------
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
 -- -------AutobackUpStart------ -- -------------------------------------------

-- -------------------------------------------

-- END BACKUP

-- -------------------------------------------
